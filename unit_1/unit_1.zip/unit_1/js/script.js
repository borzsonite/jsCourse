// Task 1
console.log("Сергей");

// Task 2
console.log(3);

// Task 3
console.log('Добро ' + 'пожаловать' + ' на курс');

// Task 4
// alert(2019);

// Task 5
// alert(2019 - 200);

// Task 6
document.getElementById('one').innerHTML = "Hello word";

// Task 7
document.getElementById('two').innerHTML = 12 * 12;

// Task 8
document.querySelector('.one').innerHTML = "Hello Word";

// Task 9
document.querySelector('h2 span').innerHTML = "world";

// Task 10
document.querySelector('.three').innerHTML = '<h3>Done!</h3>';

// Task 11
document.querySelector('.four').innerHTML = '<h4>Header</h4>';
document.querySelector('.four').innerHTML += '<p>lorem lorem</p>';

// Task 12
let a = document.querySelector('.five');
a.innerHTML = 3.1415;

// Task 13
let div7 = document.querySelector('.seven');
div7.innerHTML = '<img src="https://cdn4.iconfinder.com/data/icons/food-and-drink-flat-gradient/32/cone_ice_cream_food_drink_sweet-512.png"alt="">'

// Task 14
let z1 = 6;
let z2 = 3;
document.querySelector('.eight').innerHTML = z1 * z2;

// Task 15
let y1 = 6;
let y2 = 3;
document.querySelector('.nine').innerHTML = y1 / y2;


// Task 16
let x1 = 'Hello';
let x2 = 5;
document.querySelector('.ten').innerHTML = x1 + x2;

// Task 17
let d1 = document.querySelector('.test-1');
console.log(d1);

// Task 18
let d2 = document.querySelector('.test-2');
console.log(d2);
d2 = 5;
console.log(d2);

// Task 19
let divS3 = document.querySelector('.s3');
console.log(divS3);
divS3 = document.querySelector('.s4');
console.log(divS3);

// Task 20
// document.querySelector('body').innerHTML = '';
