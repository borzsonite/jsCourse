// TASK 1.  Напишите функцию func_1, которая присваивает p.u-1 ширину 200px.Проверьте ее работу.Допишите возможность присваивать высоту равную 100px;

function func_1() {
    const u1 = document.querySelector('.u-1');
    u1.style.width = '200px';
    u1.style.height = '100px';
}

func_1();

// TASK 2. Напишите функцию func_2, которая будучи запущенной присваивает блоку p.u-2 класс css-1. Задайте данному классу через CSS зеленый цвет фона.

function func_2() {
    const u2 = document.querySelector('p.u-2');
    u2.classList.add('css-1');
    document.querySelector('.css-1').style.background = 'green';
}

func_2();


// TASK 3. Используя цикл, добавьте на все блоки p.u - 3 событие onclick.По клику запускайте функцию func_3, которая окрашивает элемент, на котором произошло событие в красный цвет фона.Для обращения внутри функции к такому элементу используйте this.

function func_3() {
    this.style.background = 'red';
}

const u3 = document.querySelectorAll('p.u-3');
for (let i = 0; i < u3.length; i++) {
    u3[i].onclick = func_3;
}



// TASK 4. Используя цикл, добавьте на все блоки p.u - 4 событие onclick.По клику запускайте функцию func_4, которая присваивает элементу, на котором произошло событие, класс css - 2. Для обращения внутри функции к такому элементу используйте this.

function func_4() {
    this.classList.add('css-2');
}

const u4 = document.querySelectorAll('p.u-4');
for (let i = 0; i < u4.length; i++) {
    u4[i].onclick = func_4;
}

// TASK 5. C помощью цикла, повесьте на блоки p.u - 5 функцию func_5, которая при клике будет удалять класс css - 3 с элемента, на котором произошло событие.

function func_5() {
    this.classList.remove('css-3');
}

const u5 = document.querySelectorAll('p.u-5');
for (let i = 0; i < u5.length; i++) {
    u5[i].onclick = func_5;
}

// TASK 6. Есть кнопка.u - 6. Напишите функцию, которая при клике делает toggle классу.active для данной кнопки.

function func_6() {
    this.classList.toggle('active');
}
const u6 = document.querySelector('.u-6');
u6.onclick = func_6;

// TASK 7. Напишите функцию func - 7, которая будучи запущенной возвращает количество элементов с классом css-3.

function func_7() {
    const css3 = document.querySelectorAll('.css-3');
    console.log(css3.length);
}
func_7();


// TASK 8. Напишите функцию func - 8, которая будучи запущенной, присваивает всем элементам p.u - 1 атрибут title со значением test - data.

function func_8() {
    const u1 = document.querySelectorAll('.u-1');
    for (let i = 0; i < u1.length; i++) {
        u1[i].setAttribute('title', 'test-data');
    }
}
func_8();

// TASK 9. С помощью цикла получите кнопки.u - 9. Добавьте на них событие onclick которое запускает функцию func - 9. Функция возращает data атрибут элемента, по которому кликнули.

function func_9() {
    console.log(this.getAttribute('data'));
}

const u9 = document.querySelectorAll('.u-9');
for (let i = 0; i < u9.length; i++) {
    u9[i].onclick = func_9;
}

// TASK 10. Напишите функцию func - 10, которая при клике на кнопке.u -10__button читает атрибут валюты data - currency и на основании этого выводит в p.u -10__out коэффициент данной валюты по отношению к доллару.Коэффициент возьмите приблизительно из интернета.Считается, что пользователь всегда вводит валюту в долларах.

function func_10() {
    let currency = this.getAttribute('data-currency');
    let out = document.querySelector('.u-10__out');
    switch(currency){
        case 'euro':
            out.innerHTML = '0.9';
            break;
        case 'usd':
            out.innerHTML = '1';
            break;
        case 'rub':
            out.innerHTML = '62.05';
    }
 }

let currency = document.querySelectorAll('.u-10__button');
for(let i=0; i<currency.length;i++ ) {
    currency[i].onclick = func_10;
}

// TASK 11.Напишите функцию func - 11, которая при клике на кнопке.u -11__button читает атрибут валюты data - currency и на основании этого выводит в p.u -11__out перевод валюты введенной пользователем в input.u -11__input в указанную валюту.Считается, что пользователь всегда вводит валюту в долларах. 

function func_11() {
    let out = document.querySelector('.out-11__out');
    let inp = +document.querySelector('.u-11_out').value;
    let currency2 = this.getAttribute('data-currency');
    switch(currency2) {
        case 'euro':
            out.innerHTML = inp * .9;
            console.log(inp);
            break;
        case 'usd':
            out.innerHTML = inp*1;
             break;
            case 'rub':
            out.innerHTML = inp* 62.05;
    }
 }

let currency2 = document.querySelectorAll('.u-11__button');
for(let i = 0; i<currency2.length; i++) {
    currency2[i].onclick = func_11;
}
// TASK  12. Создайте функцию func - 12, которая создает через createElement элемент div, присваивает ему класс css - 4 и возвращает данный элемент



function func_12() {
   let myDiv = document.createElement('div');
   myDiv.classList.add('css-4');
   return myDiv;
 }
 console.log(func_12()); 

// TASK  13.Создайте функцию func - 13, которая создает элемент span.span - 13 с текстом 13 через createElement и вставляет его в p.u - 13(append).

function func_13() {
    let mySpan = document.createElement('span');
    mySpan.classList.add('span-13');
    mySpan.innerHTML = '_13';
    document.querySelector('p.u-13').appendChild(mySpan);
 }
 func_13();

// TASK  14. Создайте функцию func - 14, которая создает элемент span.span - 14 с текстом 14 через createElement и вставляет его в p.u - 14(prepend).

function func_14() {
    let mySpan = document.createElement('span');
    mySpan.classList.add('span-14');
    mySpan.innerHTML = '14_';
    console.log(mySpan);
    document.querySelector('p.u-14').prepend(mySpan);
 }

 func_14();

// TASK 15. Создайте функцию func - 15, которая создает элемент span.span - 15 с текстом 15 через createElement и вставляет его в p.u - 15(before)

function func_15() { 
let mySpan = document.createElement('span');
mySpan.classList.add('span-15');
mySpan.innerHTML = '15';
document.querySelector('p.u-15').before(mySpan);
}
func_15();


// TASK    16. Создайте функцию funct - 16, которая создает элемент button.u - 16 c текстом Push.Повесьте на данный элемент событие onclick со стрелочной функцией, которая в консоль выводит текст u - 16. И после добавления события добавьте данный элемент на страницу в div.u -16__out.Проверьте работоспособность события.

function func_16() { 
    let button_16 = document.createElement('button');
    button_16.classList.add('u-16');
    button_16.innerHTML = 'Push';
    document.querySelector('.u-16__out').appendChild(button_16);
    document.querySelector('.u-16').onclick =()=>{
        console.log('u-16');
    }
}
func_16();

// TASK 17. Создайте функцию, funct - 17, которая при запуске создаст элемент p c текстом 17 и заменит этим элементом div.u - 17

function func_17() { 
   let p = document.createElement('p');
   p.innerHTML = '17';
   let div17 = document.querySelector('.u-17');
   div17.parentNode.replaceChild(p, div17);
}
func_17();

// TASK 18. C помощью цикла повесьте на div.out - 18 функцию func - 18. Данная функция дожна удалять элемент, на котором произошел клик из DOM.Функция должна возвращать удаленный элемент

function func_18() {
    let div18 = document.querySelectorAll('.out-18');
    for(let i=0; i<div18.length; i++) {
        div18[i].onclick = function(){
        this.parentNode.removeChild(this);
        return this;
        }
    }
 }

func_18();

// TASK   19. Создайте функцию func - 19, которая принимает параметр текст.Создает элемент li, вставляет в него указанный текст, и добавляет на страницу в ul.u - 19 в конец списка.

function func_19(userString) {
  let li =   document.createElement('li');
  li.innerHTML = userString;
  document.querySelector('ul.u-19').appendChild(li);
 }

 func_19('my li');

// TASK 20. Доработайте предыдущее задание.Допишите функцию func - 20 которая может принимать текст от пользователя и вставлять в список ul.u - 20. Также добавьте checkbox - важное, при этом созданный li получает класс.css - 5.

function func_20(userString) { 
    let li = document.createElement('li');
    li.innerHTML = userString;
    let u20 = document.querySelector('.u-20').appendChild(li);
    if(document.getElementById('c-20').checked) {
        u20.classList.add('css-5');
    }

}
document.getElementById('b-20').onclick =()=>{
    func_20(document.getElementById('t-20').value)
}




